<?php
namespace App\Helpers;

class StudentType {
    const ACTIVE = "Active";
    const ALLUMNY = "Allumn";
}