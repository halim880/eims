<?php
namespace App\Helpers;

class ApplicationStatus {
    const PENDING = "Pending";
    const APROVED = "Approved";
    const PROCESSING = "Processing";
    const REJECTED = "Rejected";
    const SUBMITTED = "Submitted";
}