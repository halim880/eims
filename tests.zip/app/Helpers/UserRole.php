<?php 
namespace App\Helpers;

Class UserRole {
    public const STUDENT = "student";
    public const TEACHER = "teacher";
    public const HOSTEL_PROVOST = "hostel-provost";
    public const ADMIN = "admin";
    public const LIBRARIAN = "librarian";
}