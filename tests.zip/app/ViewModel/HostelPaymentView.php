<?php

namespace App\ViewModel;

use Illuminate\Database\Eloquent\Model;

class HostelPaymentView extends Model
{
    protected $table = 'hostel_payments_view';
}
