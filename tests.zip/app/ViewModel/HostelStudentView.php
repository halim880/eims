<?php

namespace App\ViewModel;

use Illuminate\Database\Eloquent\Model;

class HostelStudentView extends Model
{
    protected $table = 'hostel_students_view';
}
