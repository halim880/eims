<?php

namespace App\Http\Livewire\Student;

use Livewire\Component;

class Library extends Component
{
    public function render()
    {
        return view('livewire.student.library');
    }
}
