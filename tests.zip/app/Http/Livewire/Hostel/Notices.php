<?php

namespace App\Http\Livewire\Hostel;

use Livewire\Component;

class Notices extends Component
{
    public function render()
    {
        return view('livewire.hostel.notices');
    }
}
