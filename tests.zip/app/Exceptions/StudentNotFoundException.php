<?php

namespace App\Exceptions;

use Exception;

class StudentNotFoundException extends Exception
{
    //
}
