<?php

namespace App\Exceptions;

use Exception;

class PasswordDoesNotMatchException extends Exception
{
    //
}
