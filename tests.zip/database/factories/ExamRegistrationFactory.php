<?php

namespace Database\Factories;

use App\Models\ExamRegistration;
use Illuminate\Database\Eloquent\Factories\Factory;

class ExamRegistrationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ExamRegistration::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
