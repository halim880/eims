<?php

namespace Database\Seeders;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            // RolesTableSeeder::class,
            // DepartmentTableSeeder::class,
            // SemesterTableSeeder::class,
            // UsersTableSeeder::class,
            // StudentsTableSeeder::class,
            // CoursesTableSeeder::class,
            // HostelSeeder::class,
            // HostelStudentSeeder::class,

            // TeacherSeeder::class,

            // SliderImageTableSeeder::class,
            // EventsTableSeeder::class,
            // LibrarianSeeder::class,
            BooksTableSeeder::class,
        ]);
    }
}
