<?php

namespace App\Http\Livewire\Auth;

use Livewire\Component;

class StudentLogin extends Component
{
    public function render()
    {
        return view('livewire.auth.student-login');
    }
}
