<?php

namespace App\Http\Livewire\Student;

use Livewire\Component;

class Assignment extends Component
{
    public function render()
    {
        return view('livewire.student.assignment');
    }
}
