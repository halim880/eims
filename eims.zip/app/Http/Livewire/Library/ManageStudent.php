<?php

namespace App\Http\Livewire\Library;

use Livewire\Component;

class ManageStudent extends Component
{
    public function render()
    {
        return view('livewire.library.manage-student');
    }
}
