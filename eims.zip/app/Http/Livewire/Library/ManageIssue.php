<?php

namespace App\Http\Livewire\Library;

use Livewire\Component;

class ManageIssue extends Component
{
    public function render()
    {
        return view('livewire.library.manage-issue');
    }
}
