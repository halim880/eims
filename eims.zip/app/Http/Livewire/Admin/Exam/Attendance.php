<?php

namespace App\Http\Livewire\Admin\Exam;

use Livewire\Component;

class Attendance extends Component
{
    public function render()
    {
        return view('livewire.admin.exam.attendance');
    }
}
