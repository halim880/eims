<?php

namespace App\Http\Livewire\Admin\Teacher;

use Livewire\Component;

class Courses extends Component
{
    public function render()
    {
        return view('livewire.admin.teacher.courses');
    }
}
