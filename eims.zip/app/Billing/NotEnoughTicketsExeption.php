<?php

namespace App\Billing;

class NotEnoughTicketsExeption extends \RuntimeException{
    
}