<?php

namespace App\ViewModel;
use Illuminate\Database\Eloquent\Model;

class ResultView extends Model{
    protected $table = "results_view";
}

