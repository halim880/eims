<?php 

namespace App\Helpers;


class PaymentStatus {
    const DUE = "Due";
    const PAID = "Paid";
    const PROCESSING = "Processing";
}