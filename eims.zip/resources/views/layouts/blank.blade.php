@extends('layouts.base')

@section('root')
    <div class="container">
        {{$slot}}
    </div>
@endsection