<?php

namespace App\Billing;

class PaymentFailedException extends \RuntimeException{
    
}