<?php

namespace App\Exceptions;

use Exception;

class TeacherNotFoundException extends Exception
{
    //
}
