<?php

namespace App\Helpers;

class ExamStatus {
    const ONGONOING = "Ongoing";
    const UPCOMING = "Upcoming";
    const COMPLETED = "Completed";
}