<?php 
namespace App\Helpers;

Class UserRole {
    public const STUDENT = "Student";
    public const TEACHER = "Teacher";
    public const HOSTEL_PROVOST = "Hostel Provost";
    public const ADMIN = "Admin";
    public const LIBRARIAN = "Librarian";
    public const DATA_ENTRY_OPERATOR  = "Data Entry Operator";
}