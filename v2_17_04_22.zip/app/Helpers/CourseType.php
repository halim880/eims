<?php

namespace App\Helpers;

class CourseType {
    const DROP_COURSE = "Drop course";
    const REGULAR = "Regular";
    const ADVANCE = "Advance";
}
