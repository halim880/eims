<?php
namespace App\Helpers;

class SessionAdmissionStatus {
    const NOT_STARTED = "Not Started";
    const COMPLETED = "Completed";
    const ONGONOING = "Ongoing";
    const CLOSED = "Closed";
}