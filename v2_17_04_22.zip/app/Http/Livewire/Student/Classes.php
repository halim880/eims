<?php

namespace App\Http\Livewire\Student;

use Livewire\Component;

class Classes extends Component
{
    public function render()
    {
        return view('livewire.student.classes');
    }
}
