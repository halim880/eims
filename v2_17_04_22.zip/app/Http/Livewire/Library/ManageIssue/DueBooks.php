<?php

namespace App\Http\Livewire\Library\ManageIssue;

use Livewire\Component;

class DueBooks extends Component
{
    public function render()
    {
        return view('livewire.library.manage-issue.due-books');
    }
}
