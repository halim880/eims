<?php

namespace App\Http\Livewire\Library\Book;

use Livewire\Component;

class BookEntry extends Component
{
    public function render()
    {
        return view('livewire.library.book.book-entry');
    }
}
