<?php

namespace App\Http\Livewire\Library;

use Livewire\Component;

class Students extends Component
{
    public function render()
    {
        return view('livewire.library.students');
    }
}
