<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TestController extends Controller
{
    public function home(){
        return view('test');
    }

    public function check(){
        return 'checked';
    }
}
